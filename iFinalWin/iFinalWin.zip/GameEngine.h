#pragma once
class GameEngine
{
public:
	GameEngine();
	~GameEngine();
};

