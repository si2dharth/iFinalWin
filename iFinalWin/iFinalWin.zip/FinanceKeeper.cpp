#include"TextBox.h"

void InitLoginWindow(Window *W) {
	
}

int FinanceKeeper(char[]) {
	Window LoginWindow(InitLoginWindow);
	return 0;
}