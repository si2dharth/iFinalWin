#pragma once
#include "DDrawing.h"

class GameObject : public DDrawing
{
public:
	GameObject();
	~GameObject();
};

