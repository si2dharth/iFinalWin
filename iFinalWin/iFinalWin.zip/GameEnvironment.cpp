#include "GameEnvironment.h"


GameEnvironment::GameEnvironment(Window *W, bool FullScreen) : DGraphics(W, FullScreen)
{
}


GameEnvironment::~GameEnvironment()
{
}
