#pragma once
#include "EventHandler.h"

template <class T>
class Primitive < T > {
	T value;
public:

};