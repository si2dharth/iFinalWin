#pragma once
#include "GameObject.h"

class Sprite : public GameObject
{
public:
	Sprite();
	~Sprite();
};

