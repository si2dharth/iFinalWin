#include "DDrawing.h"

DGraphics *DShape::defContainer = 0;
DGraphics *DDrawing::defContainer = 0;