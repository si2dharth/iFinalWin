#include "iBase.h"
#include "iGraphics.h"
#include "Physics.h"

class PObject : public PhysicsObject
{
public:
	PObject();
	void draw();
};